package br.edu.icomp.ufam.laboratorio4;

abstract class FormaGeometrica2D extends FormaGeometrica{

	public FormaGeometrica2D(String descricao){
		super(descricao);
	}
	abstract float getArea();

}