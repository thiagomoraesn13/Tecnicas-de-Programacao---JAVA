package br.edu.icomp.ufam.laboratorio4;

class FormaGeometrica{
	String descricao;

	public FormaGeometrica(String descricao){
		this.descricao = descricao;
	}
	public String getDestricao(){
		return descricao;
	} 
}