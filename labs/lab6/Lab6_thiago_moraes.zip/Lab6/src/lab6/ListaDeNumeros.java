package lab6;
import java.util.*;
import java.io.*;

public class ListaDeNumeros{
    File doc;
    ArrayList<Double> vet = new ArrayList();
    void abrir(String nome) throws NullPointerException, FileNotFoundException{                        
        this.doc = new File(nome);
        Scanner scanner = new Scanner(doc);
        if (nome == null) throw new NullPointerException();
        Double i=0.0;
        while(scanner.hasNext()){
           vet.add(scanner.nextDouble());
        }
    }
    
    public Double media() throws ArithmeticException { 
        
        Iterator <Double> iterator = vet.iterator();
        Double media=0.0;
        while(iterator.hasNext()){    
                media = media + iterator.next();
        }
        if(media != null){ 
        return media / vet.size();
        }
        else{
             throw new ArithmeticException();
        }
    
    }
    
}
