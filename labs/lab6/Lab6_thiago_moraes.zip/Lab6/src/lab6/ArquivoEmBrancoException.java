
package lab6;
class ArquivoEmBrancoException extends Exception {
    private static final long serialVersionUID = 1L;

    public ArquivoEmBrancoException() {
        this("Arquivo em Branco");
    }
    public ArquivoEmBrancoException(String s) {
        super(s);
    }    
}
