package lab6;
import java.util.*;
import java.io.*;

public class Lab6 {

    public static void main(String[] args)throws NullPointerException, FileNotFoundException, ArquivoForaDoPadraoException, ArquivoEmBrancoException, ArithmeticException{
       ListaDeNumeros teste = new ListaDeNumeros();
       //teste.abrir("/home/thiago-moraes/NetBeansProjects/Lab6/src/lab6/nome.txt");
       //System.out.println(teste.media());
       try{
        teste.abrir("/home/thiago-moraes/NetBeansProjects/Lab6/src/lab6/nome.txt");       
          System.out.println(teste.media());
        }
        catch(NullPointerException e){
            System.out.println("Erro de Apontamento pra nuloo");
        }
        catch(FileNotFoundException e){
            System.out.println("Arquivo não encontrado");
        }
        catch(ArquivoForaDoPadraoException e){
            System.out.println("Arquivo Fora do Padrão");
        }
        catch(ArquivoEmBrancoException e){
            System.out.println("Arquivo em Branco");
        }
        catch(ArithmeticException e){
            System.out.println("Erro Aritmético");
        }
    
    }
}
