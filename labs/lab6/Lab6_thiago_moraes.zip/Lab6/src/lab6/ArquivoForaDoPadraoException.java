
package lab6;
public class ArquivoForaDoPadraoException extends Exception{
    private static final long serialVersionUID = 1L;

    public ArquivoForaDoPadraoException() {
        this("Arquivo Fora do Padrão");
    }
    public ArquivoForaDoPadraoException(String s) {
        super(s);
    }
}